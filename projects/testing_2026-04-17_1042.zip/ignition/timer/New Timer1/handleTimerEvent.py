def handleTimerEvent():
	import os
	os.system("cd C:/IgnitionRepo && git pull origin master")