def handleTimerEvent():
	import os
	
	os.system('curl -X POST http://localhost:8088/system/project/import -F "file=@C:/IgnitionRepo/project/project.proj"')	