def handleTimerEvent():
	import os
	import json
	import system.tag
	
	BASE_PATH = "C:/IgnitionRepo"
	
	def deploy_tags():
	    tag_file = BASE_PATH + "/tags/udt/MotorUDT.json"
	    
	    if os.path.exists(tag_file):
	        with open(tag_file, 'r') as f:
	            tags = json.load(f)
	
	        system.tag.configure(
	            basePath="[default]_types_",
	            tags=tags,
	            collisionPolicy="o"
	        )
	
	        system.util.getLogger("DEPLOY").info("✅ UDT Deployed")
	
	def deploy_instances():
	    tag_file = BASE_PATH + "/tags/instances/Motor1.json"
	    
	    if os.path.exists(tag_file):
	        with open(tag_file, 'r') as f:
	            tags = json.load(f)
	
	        system.tag.configure(
	            basePath="[default]",
	            tags=tags,
	            collisionPolicy="o"
	        )
	
	        system.util.getLogger("DEPLOY").info("✅ Tags Deployed")
	
	def run_deployment():
	    deploy_tags()
	    deploy_instances()
	
	# Run after startup
	system.util.invokeLater(run_deployment, 5000)